 package main

import (
    "fmt"
    "time"
)

func main() {
    time.Sleep(3 * time.Second)
    fmt.Println("hi")
}